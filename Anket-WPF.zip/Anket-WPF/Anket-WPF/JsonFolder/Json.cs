﻿using Anket_WPF.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace Anket_WPF.JsonFolder
{
    public static class JsonFile
    {
        public static void WriteNames(string filePath, string data)
        {
            var list = ReadNames(filePath);
            list.Add(data);
            string json = JsonConvert.SerializeObject(list);
            File.WriteAllText(filePath, json);

        }
        public static List<string> ReadNames(string filePath)
        {
            return JsonConvert.DeserializeObject<List<string>>(File.ReadAllText(filePath));
        }
        public static void WriteToFile(string filePath, Person person)
        {
            string json = JsonConvert.SerializeObject(person);
            File.WriteAllText(filePath, json);

        }
        public static Person readPerson(string fileName)
        {
            string json = File.ReadAllText("../../../../Anket-WPF/DataBase/" + fileName+".json");
            var collectionItems = JsonConvert.DeserializeObject<Person>(json);
            return collectionItems;
        }
        public static void addPerson(string name, Person person)
        {
            string path="../../../../Anket-WPF/DataBase/" + name + ".json";
            WriteToFile(path, person);
        }

    }
}
