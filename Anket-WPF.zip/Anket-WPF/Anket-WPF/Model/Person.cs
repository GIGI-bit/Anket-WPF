﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anket_WPF.Model
{
    public class Person
    {
        private string name;
        private string surname;
        private string fatherName;
        private string country;
        private string phone;
        private DateTime? birthDate;
        private string gender;
        private string city;

        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string FatherName { get => fatherName; set => fatherName = value; }
        public string Country { get => country; set => country = value; }
        public string City { get => city; set => city = value; }
        public string Phone { get => phone; set => phone = value; }
        public DateTime? BirthDate { get => birthDate; set => birthDate = value; }
        public string Gender { get => gender; set => gender = value; }

        public Person()
        {
            
        }


    }
}
