﻿using Anket_WPF.JsonFolder;
using Anket_WPF.Model;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Anket_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            combo_box.ItemsSource = JsonFile.ReadNames("../../../../Anket-WPF/DataBase/FileNames.json");
        }

        private void btn_load(object sender, RoutedEventArgs e)
        {
            Person person = JsonFile.readPerson(combo_box.Text);
            ad_tbox.Text = person.Name;
            soyad_tbox.Text = person.Surname;
            AtaAdi_tbox.Text = person.FatherName;
            tel_tbox.Text = person.Phone;
            date_picker.Text = person.BirthDate.ToString();
            olke_tbox.Text = person.Country;
            seher_tbox.Text = person.City;
            if (person.Gender == "Male") male_rbtn.IsChecked = true;
            else if (person.Gender == "Female") female_rbtn.IsChecked = true;

        }

        private void btn_save(object sender, RoutedEventArgs e)
        {
            var newPerson = new Person();
            newPerson.Name = ad_tbox.Text;
            newPerson.Surname = soyad_tbox.Text;
            newPerson.FatherName = AtaAdi_tbox.Text;
            newPerson.Phone = tel_tbox.Text;
            newPerson.BirthDate = date_picker.SelectedDate;
            newPerson.Country = olke_tbox.Text;
            newPerson.City = seher_tbox.Text;
            if (male_rbtn.IsChecked == true) newPerson.Gender = "Male";
            else if (female_rbtn.IsChecked == true) newPerson.Gender = "Female";

            if (combo_box.Text == "") MessageBox.Show("File name CANNOT be NULL!");
            else
            {
                JsonFile.addPerson(combo_box.Text, newPerson);
                var list = JsonFile.ReadNames("../../../../Anket-WPF/DataBase/FileNames.json");
                if (!list.Contains(combo_box.Text))
                {
                    JsonFile.WriteNames("../../../../Anket-WPF/DataBase/FileNames.json", combo_box.Text);
                    combo_box.ItemsSource = list;
                }
                MessageBox.Show("New Person created!");
            }

        }
    }
}